
package hr.obskc.baci.rpg;
public class RPG {

    public static void main(String[] args) {
        System.out.println("RPG");
    
    /*    Knight iva = new Knight("iva",5,10,8);
        System.out.println(iva.toString());
        System.out.println(iva);
        System.out.println("Napad: " + iva.attackPower() + ",obrana: " + iva.defense());
        System.out.println("Sažetak: " + iva.summary());
*/
    GameCharacter[] party = {
        new Warrior("Borna",3,12),
        new Knight("Iva",5,10,8),
        new Mage("Lana",4,40),
        new Mage("Toma",2,20),
        new Archer("Mia",3,30),
        new Archer("Filip",1,6)
        // new GameCharacter("pero", 10); apstraktna klasa se ne moze definirati
    };
        
        System.out.println("=== Družina ===");
        for (GameCharacter gameCharacter : party) {
            System.out.println(gameCharacter.summary());
        }
        
        double totalAttack = 0;
        for (GameCharacter gameCharacter : party) {
            totalAttack += gameCharacter.attackPower();
        }
        System.out.printf("Ukupni napad družine: %.2f %n",totalAttack);
        
        System.out.println("Najotporniji član  družine:" + toughest(party).summary());
        
        System.out.println("=== PPoosebnosti ===");
        for (GameCharacter c : party){
            if (c instanceof Knight k){
                System.out.println(k.getName() + ": vitez s oklopom" + k.getArmor());
            }
            else if (c instanceof Warrior w){
                System.out.println(w.getName() + ": ratnik sa snagom" + w.getStrength());
            }
            else if (c instanceof Mage m){
                System.out.println(m.getName() + 
                        (m.canCastFireball()?
                        ": može baciti vatren kuglu.":
                        ": neam dovoljno mane za vatrenu kuglu"
                        ));
            }
             else if (c instanceof Archer a){
                System.out.println(a.getName() + (a.needsArrows()?
                        ": može baciti vatren kuglu.":
                        ": neam dovoljno mane za vatrenu kuglu"
                        ));
        }
    
    /*
            Drvo nasljeđivanja:
            
            GameCharacter (abstract)
            |
            |-Warrior -|
            |          |-Knight
            |
            |-Mage
            |
            |-Archer
            
            
            
            
            
            
            
            
        Warrior borna = new Warrior("Borna",3,12);
      
        
        System.out.println(borna.getName()+", razina " + borna.getLevel() + ", snaga " + borna.getStrength());
        System.out.println("Napad (naslijeđen): " + borna.attackPower());
        
        Warrior bornaCopy = new Warrior("Borna",4,15);
        System.out.println(borna);
        System.out.println(bornaCopy);
        
        System.out.println("borna == bornaCopy: " + (borna == bornaCopy));
        System.out.println("borna.equals(bornaCopy): "+ borna.equals(bornaCopy));
*/ 
    }
    
    static GameCharacter toughest(GameCharacter[] party){
        GameCharacter best = party[0];
        for (GameCharacter gameCharacter : party) {
            if (gameCharacter.defense() >best.defense()){
                best = gameCharacter;
            }
        }
        return best;
    }
    
}
