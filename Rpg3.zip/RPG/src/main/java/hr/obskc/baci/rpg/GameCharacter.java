package hr.obskc.baci.rpg;

import java.util.Objects; //klasa koja sadrzi korisne alate za rad s klasam i objektima
        
// apstaktna klasa ne moze se instancirati (odnosno stvoriti objekt te klase), vec sluzi samo kao nadklasa za nasljeđivanje
public abstract class GameCharacter {
    
    private String name;
    private int level;
    
    public GameCharacter(String name, int level) {
        if (name == null || name.isBlank())
        {
            throw new IllegalArgumentException("Ime lika ne smije biti prazno");
        }
        this.name = name;
        this.level= level;
        
        System.out.println("Pokreće se konstruktor GameCharacter");
    }
    
    public String getName(){
        return name;
    }
     public int getLevel(){
          return level;
    }
     
    protected double levelBonus(){
        return level * 1.5;
    }
    
    //svala špdlčasa mora imati te metode i mora dati njihovu implementaciju
    //medutim metoda definirana kao apstraktna NE SMIJE i ne moze imiati tijelo.
    public abstract double attackPower();
    public abstract double defense();
        
    

    public String summary(){
        return String.format("%s -> napad %.2f , obrana %.2f", this, attackPower(),defense());
    }
    
    @Override
    public String toString() {
        return "ime=" + name + ", razina=" + level;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
        GameCharacter other = (GameCharacter) obj;
        return name.equals((other.name));
        
    }
    @Override
    public int hashCode(){
        return Objects.hash(name);
    }
                
    
}
