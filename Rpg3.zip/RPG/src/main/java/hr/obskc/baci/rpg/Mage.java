
package hr.obskc.baci.rpg;

public class Mage extends GameCharacter{
    
    private int mana;
    
    public Mage(String name, int level, int mana){
        super(name,level);
        this.mana = mana;
    }
    public boolean canCastFireball(){
       return mana >=30;
    }

    @Override
    public double attackPower() {
        return mana * 1.5 + levelBonus();
    }

    @Override
    public double defense() {
        return levelBonus();
    }

    @Override
    public String toString() {
        return "Čarobnjak[" + super.toString() + ", mana=" + mana + "]";
    }
    
    
    
    
    
    
}
