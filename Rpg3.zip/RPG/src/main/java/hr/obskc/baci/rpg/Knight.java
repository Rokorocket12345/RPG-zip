package hr.obskc.baci.rpg;

public final class Knight extends Warrior { //klasa se ne može višse nasljeđivati -> final
    
    private int armor;
    
    public Knight(String name, int level,int strength, int armor){
        super(name, level, strength);
        this.armor = armor;
    }

    public int getArmor() {
        return armor;
    }
    

    @Override
    public double defense() {
        return super.defense() + armor;
      
    }

    @Override
    public String toString() {
        return "Vitez[ime=" + getName() +", razina=" + getLevel() + ", snaga=" + getStrength() + ", oklop=" + armor + "]" ;
    }
    
    
    
    
}
