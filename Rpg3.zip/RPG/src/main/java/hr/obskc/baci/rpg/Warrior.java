package hr.obskc.baci.rpg;

public class Warrior extends GameCharacter {  //eksplicitno izvedena klasa -> nasljeduje klasu Object (dio Jave)
    
    private int strength;
    
    public Warrior(String name, int level, int strength){
        super(name, level);
        this.strength = strength;
        System.out.println("Pokreće se konstruktor Warrior");
    }
    
    public int getStrength(){
        return strength;
    }

    @Override
    public double attackPower() {
        return strength * 2 + levelBonus();
    }

    @Override
    public double defense() {
        return strength + levelBonus();
    }

    @Override
    public String toString() {
        return "Ratnik[" +super.toString() + ", snaga=" + strength + "]";
    }
    
    
    
    
    
}
