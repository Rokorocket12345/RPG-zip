
package hr.obskc.baci.rpg;


public class Archer extends GameCharacter {
    
    private int arrows;
    public Archer(String name, int level, int arrows){
        super(name, level);
        this.arrows = arrows;
        
    }
    public boolean needsArrows(){
        return arrows < 10;
    }

    @Override
    public double attackPower() {
        return arrows * 0.5 + levelBonus(); 
    }

    @Override
    public double defense() {
        return 6 + levelBonus(); 
    }

    @Override
    public String toString() {
        return "Strijelac[" +super.toString() + ", strijele=" + arrows + "]"; 
    }
    
    
    
    
    
    
}
