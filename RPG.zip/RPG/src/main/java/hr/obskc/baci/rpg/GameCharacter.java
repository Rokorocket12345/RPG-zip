package hr.obskc.baci.rpg;

import java.util.Objects; //klasa koja sadrzi korisne alate za rad s klasam i objektima
        
public class GameCharacter {
    
    private String name;
    private int level;
    
    public GameCharacter(String name, int level) {
        if (name == null || name.isBlank())
        {
            throw new IllegalArgumentException("Ime lika ne smije biti prazno");
        }
        this.name = name;
        this.level= level;
        
        System.out.println("Pokreće se konstruktor GameCharacter");
    }
    
    public String getName(){
        return name;
    }
     public int getLevel(){
          return level;
    }
     
    protected double levelBonus(){
        return level * 1.5;
    }
    
    public double attackPower(){
       return levelBonus();
       
    }
    
    public double defense() {
        return levelBonus();
    }

    @Override
    public String toString() {
        return "ime=" + name + ", razina=" + level;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
        GameCharacter other = (GameCharacter) obj;
        return name.equals((other.name));
        
    }
    @Override
    public int hashCode(){
        return Objects.hash(name);
    }
                
    
}
