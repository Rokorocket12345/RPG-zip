
package hr.obskc.baci.rpg;
public class RPG {

    public static void main(String[] args) {
        System.out.println("RPG");
    
        Knight iva = new Knight("iva",5,10,8);
        System.out.println(iva.toString());
        System.out.println(iva);
        System.out.println("Napad: " + iva.attackPower() + ",obrana: " + iva.defense());
        
        Warrior borna = new Warrior("Borna",3,12);
      
        
        System.out.println(borna.getName()+", razina " + borna.getLevel() + ", snaga " + borna.getStrength());
        System.out.println("Napad (naslijeđen): " + borna.attackPower());
        
        Warrior bornaCopy = new Warrior("Borna",4,15);
        System.out.println(borna);
        System.out.println(bornaCopy);
        
        System.out.println("borna == bornaCopy: " + (borna == bornaCopy));
        System.out.println("borna.equals(bornaCopy): "+ borna.equals(bornaCopy));
        
        
    }
    
}
